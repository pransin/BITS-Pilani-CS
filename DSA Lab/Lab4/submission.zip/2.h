unsigned int spaceInHeap;
void *myalloc(unsigned int m);
void *myfree(void *ptr, int size);