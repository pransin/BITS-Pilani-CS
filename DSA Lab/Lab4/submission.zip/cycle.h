#include <stdbool.h>
#include "linkedlist.h"

bool testCyclic(node *Ls);